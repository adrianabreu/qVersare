/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[24];
    char stringdata0[324];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 18), // "emitUpdateUserList"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 8), // "username"
QT_MOC_LITERAL(4, 40, 4), // "time"
QT_MOC_LITERAL(5, 45, 21), // "on_exitButton_clicked"
QT_MOC_LITERAL(6, 67, 23), // "on_conectButton_clicked"
QT_MOC_LITERAL(7, 91, 22), // "on_aboutButton_clicked"
QT_MOC_LITERAL(8, 114, 29), // "on_SendTextEdit_returnPressed"
QT_MOC_LITERAL(9, 144, 21), // "on_confButton_clicked"
QT_MOC_LITERAL(10, 166, 11), // "readyToRead"
QT_MOC_LITERAL(11, 178, 3), // "aux"
QT_MOC_LITERAL(12, 182, 22), // "on_imageButton_clicked"
QT_MOC_LITERAL(13, 205, 10), // "send_login"
QT_MOC_LITERAL(14, 216, 8), // "password"
QT_MOC_LITERAL(15, 225, 13), // "refreshAvatar"
QT_MOC_LITERAL(16, 239, 8), // "filename"
QT_MOC_LITERAL(17, 248, 9), // "setAvatar"
QT_MOC_LITERAL(18, 258, 7), // "addUser"
QT_MOC_LITERAL(19, 266, 10), // "searchUser"
QT_MOC_LITERAL(20, 277, 16), // "refreshLocalUser"
QT_MOC_LITERAL(21, 294, 10), // "needAvatar"
QT_MOC_LITERAL(22, 305, 12), // "updateAvatar"
QT_MOC_LITERAL(23, 318, 5) // "image"

    },
    "MainWindow\0emitUpdateUserList\0\0username\0"
    "time\0on_exitButton_clicked\0"
    "on_conectButton_clicked\0on_aboutButton_clicked\0"
    "on_SendTextEdit_returnPressed\0"
    "on_confButton_clicked\0readyToRead\0aux\0"
    "on_imageButton_clicked\0send_login\0"
    "password\0refreshAvatar\0filename\0"
    "setAvatar\0addUser\0searchUser\0"
    "refreshLocalUser\0needAvatar\0updateAvatar\0"
    "image"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   94,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,   99,    2, 0x08 /* Private */,
       6,    0,  100,    2, 0x08 /* Private */,
       7,    0,  101,    2, 0x08 /* Private */,
       8,    0,  102,    2, 0x08 /* Private */,
       9,    0,  103,    2, 0x08 /* Private */,
      10,    1,  104,    2, 0x08 /* Private */,
      12,    0,  107,    2, 0x08 /* Private */,
      13,    2,  108,    2, 0x0a /* Public */,
      15,    1,  113,    2, 0x0a /* Public */,
      17,    1,  116,    2, 0x0a /* Public */,
      18,    2,  119,    2, 0x0a /* Public */,
      19,    1,  124,    2, 0x0a /* Public */,
      20,    2,  127,    2, 0x0a /* Public */,
      21,    2,  132,    2, 0x0a /* Public */,
      22,    3,  137,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QDateTime,    3,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   11,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,   14,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::QDateTime,    3,    4,
    QMetaType::Int, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::QDateTime,    3,    4,
    QMetaType::Void, QMetaType::QString, QMetaType::QDateTime,    3,    4,
    QMetaType::Void, QMetaType::QString, QMetaType::QDateTime, QMetaType::QPixmap,    3,    4,   23,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->emitUpdateUserList((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2]))); break;
        case 1: _t->on_exitButton_clicked(); break;
        case 2: _t->on_conectButton_clicked(); break;
        case 3: _t->on_aboutButton_clicked(); break;
        case 4: _t->on_SendTextEdit_returnPressed(); break;
        case 5: _t->on_confButton_clicked(); break;
        case 6: _t->readyToRead((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->on_imageButton_clicked(); break;
        case 8: _t->send_login((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->refreshAvatar((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->setAvatar((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->addUser((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2]))); break;
        case 12: { int _r = _t->searchUser((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 13: _t->refreshLocalUser((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2]))); break;
        case 14: _t->needAvatar((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2]))); break;
        case 15: _t->updateAvatar((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2])),(*reinterpret_cast< QPixmap(*)>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)(QString , QDateTime );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::emitUpdateUserList)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::emitUpdateUserList(QString _t1, QDateTime _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
