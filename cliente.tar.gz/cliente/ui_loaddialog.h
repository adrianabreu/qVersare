/********************************************************************************
** Form generated from reading UI file 'loaddialog.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOADDIALOG_H
#define UI_LOADDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_loadDialog
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_3;
    QLabel *image;
    QLabel *label;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *searchButton;
    QPushButton *camPushButton;
    QSpacerItem *horizontalSpacer;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *loadDialog)
    {
        if (loadDialog->objectName().isEmpty())
            loadDialog->setObjectName(QStringLiteral("loadDialog"));
        loadDialog->resize(431, 212);
        verticalLayout = new QVBoxLayout(loadDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_3 = new QLabel(loadDialog);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout->addWidget(label_3);

        image = new QLabel(loadDialog);
        image->setObjectName(QStringLiteral("image"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(image->sizePolicy().hasHeightForWidth());
        image->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(image);

        label = new QLabel(loadDialog);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        searchButton = new QPushButton(loadDialog);
        searchButton->setObjectName(QStringLiteral("searchButton"));

        horizontalLayout_2->addWidget(searchButton);

        camPushButton = new QPushButton(loadDialog);
        camPushButton->setObjectName(QStringLiteral("camPushButton"));

        horizontalLayout_2->addWidget(camPushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        buttonBox = new QDialogButtonBox(loadDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        horizontalLayout_2->addWidget(buttonBox);


        verticalLayout->addLayout(horizontalLayout_2);


        retranslateUi(loadDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), loadDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), loadDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(loadDialog);
    } // setupUi

    void retranslateUi(QDialog *loadDialog)
    {
        loadDialog->setWindowTitle(QApplication::translate("loadDialog", "Avatar", 0));
        label_3->setText(QString());
        image->setText(QString());
        label->setText(QString());
        searchButton->setText(QApplication::translate("loadDialog", "Examinar...", 0));
        camPushButton->setText(QApplication::translate("loadDialog", "WebCam", 0));
    } // retranslateUi

};

namespace Ui {
    class loadDialog: public Ui_loadDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOADDIALOG_H
