#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QRegExp>
#include <QDebug>
#include <QPixmap>
#include "client.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:
    void on_exitButton_clicked();

    void on_conectButton_clicked();

    void on_aboutButton_clicked();

    void on_SendTextEdit_returnPressed();

    void on_confButton_clicked();

    void readyToRead(QString aux);

    void on_imageButton_clicked();


public slots:
    void send_login(QString username, QString password);

    void refreshAvatar(QString filename);

    void setAvatar(QString username);

private:
    Ui::MainWindow *ui;
    bool isConectedButton_;
    bool isConectedToServer_;
    Client *client_;
    QString path_;
};

#endif // MAINWINDOW_H
