#ifndef CAMERADIALOG_H
#define CAMERADIALOG_H

#include <QDialog>

namespace Ui {
class cameradialog;
}

class QCamera;
class QCameraViewfinder;
class QCameraImageCapture;
class QVBoxLayout;

class cameradialog : public QDialog
{
    Q_OBJECT

public:
    explicit cameradialog(QWidget *parent = 0);
    ~cameradialog();

private slots:
    void on_onPushButton_clicked();

    void on_offPushButton_clicked();

    void on_captPushButton_clicked();

    void on_exitPushButton_clicked();

private:
    Ui::cameradialog *ui;
    QCamera *mCamera;
    QCameraViewfinder *mCameraViewfinder;
    QCameraImageCapture *mCameraImageCapture;
    QVBoxLayout *mLayout;
};

#endif // CAMERADIALOG_H
