/********************************************************************************
** Form generated from reading UI file 'cameradialog.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CAMERADIALOG_H
#define UI_CAMERADIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cameradialog
{
public:
    QVBoxLayout *verticalLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QHBoxLayout *horizontalLayout;
    QPushButton *onPushButton;
    QPushButton *offPushButton;
    QPushButton *captPushButton;
    QPushButton *exitPushButton;

    void setupUi(QDialog *cameradialog)
    {
        if (cameradialog->objectName().isEmpty())
            cameradialog->setObjectName(QStringLiteral("cameradialog"));
        cameradialog->resize(400, 300);
        verticalLayout = new QVBoxLayout(cameradialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        scrollArea = new QScrollArea(cameradialog);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 380, 245));
        scrollArea->setWidget(scrollAreaWidgetContents);

        verticalLayout->addWidget(scrollArea);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        onPushButton = new QPushButton(cameradialog);
        onPushButton->setObjectName(QStringLiteral("onPushButton"));

        horizontalLayout->addWidget(onPushButton);

        offPushButton = new QPushButton(cameradialog);
        offPushButton->setObjectName(QStringLiteral("offPushButton"));

        horizontalLayout->addWidget(offPushButton);

        captPushButton = new QPushButton(cameradialog);
        captPushButton->setObjectName(QStringLiteral("captPushButton"));

        horizontalLayout->addWidget(captPushButton);

        exitPushButton = new QPushButton(cameradialog);
        exitPushButton->setObjectName(QStringLiteral("exitPushButton"));

        horizontalLayout->addWidget(exitPushButton);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(cameradialog);

        QMetaObject::connectSlotsByName(cameradialog);
    } // setupUi

    void retranslateUi(QDialog *cameradialog)
    {
        cameradialog->setWindowTitle(QApplication::translate("cameradialog", "Dialog", 0));
        onPushButton->setText(QApplication::translate("cameradialog", "Encender", 0));
        offPushButton->setText(QApplication::translate("cameradialog", "Apagar", 0));
        captPushButton->setText(QApplication::translate("cameradialog", "Capturar", 0));
        exitPushButton->setText(QApplication::translate("cameradialog", "Salir", 0));
    } // retranslateUi

};

namespace Ui {
    class cameradialog: public Ui_cameradialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CAMERADIALOG_H
