#include "cameradialog.h"
#include "ui_cameradialog.h"
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QVBoxLayout>

cameradialog::cameradialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::cameradialog)
{
    ui->setupUi(this);
    mCamera = new QCamera(this);
    mCameraViewfinder = new QCameraViewfinder(this);
    mCameraImageCapture = new QCameraImageCapture(mCamera, this);
    mLayout = new QVBoxLayout;

    mCamera->setViewfinder(mCameraViewfinder);
    mLayout->addWidget(mCameraViewfinder);
    mLayout->setMargin(0);
    ui->scrollArea->setLayout(mLayout);
}

cameradialog::~cameradialog()
{
    delete ui;
}

void cameradialog::on_onPushButton_clicked()
{
    mCamera->start();
}

void cameradialog::on_offPushButton_clicked()
{
    mCamera->stop();
}

void cameradialog::on_captPushButton_clicked()
{
    QString filename = "/home/skained/Escritorio/prueba.jpg";
    mCameraImageCapture->setCaptureDestination(
                QCameraImageCapture::CaptureToBuffer);
    QImageEncoderSettings imageEncoderSettings;
    //imageEncoderSettings.setCodec("image/jpeg");
    //imageEncoderSettings.setResolution(100, 100);
    //mCameraImageCapture->setEncodingSettings(imageEncoderSettings);
    mCamera->setCaptureMode(QCamera::CaptureStillImage);
    mCamera->start();
    mCamera->searchAndLock();
    if(mCameraImageCapture->isReadyForCapture()) {
        QPixmap image;
        //image.load(mCameraImageCapture->CaptureToBuffer);
        mCameraImageCapture->capture(filename);
        mCamera->unlock();

    } else {
        mCamera->unlock();
        mCamera->stop();
    }
}

void cameradialog::on_exitPushButton_clicked()
{

}
